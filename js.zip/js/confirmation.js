function deleteConfirm()
{
    var result = confirm("Are you sure you want to delete the selected entries?");
    if(result)
    {
        return true;
    }
    else
    {
        return false;
    }
}
function updateConfirm()
{
    var result = confirm("The update will overwrite any role that might already exist!");
    if(result)
    {
        return true;
    }
    else
    {
        return false;
    }
}
function thumbnailConfirm()
{
    var result = confirm("Thumbnail for all Selected entries would be modified!\n Are you sure you want to make these changes?");
    if(result)
    {
        return true;
    }
    else
    {
        return false;
    }
}