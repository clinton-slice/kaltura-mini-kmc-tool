
 var input_query = ""; 
var media_query = $( "input#query" );
var user_query = $( "input#users" );
var spinner = $( "#spinner" );
var user_spinner = $( "#user_spinner" );
var updating_entries = $( "#updating_entries" );

$(function () {

    user_query.tagsinput({
        typeahead: {
            source: function (query, process) {
                user_spinner.toggleClass('invisible');
                return $.get('get_users.php', { query: query }, function (response) {
                    user_spinner.toggleClass('invisible');
                    return response;
                });
            },
            minLength: 3,
            delay: 500,
            items: 4,
            afterSelect: function(val) {
                this.$element.val("");
            }
        },
        freeInput: false
    });

    kalturaDataTable = $( "#entries" ).DataTable( {
        ajax: {
            url: "get_entries.php",
            data: function ( d ) {
                d.query = input_query;
            },
            dataSrc: "",
            complete: function() {
                spinner.toggleClass('invisible');
            },
            beforeSend: function () {
                spinner.toggleClass('invisible');
            }
        },
        columnDefs: [ {
            "render": function (data, type, row) {
                return '<img width="80" height="45" src="'+ data +'"></>';
            },
            "targets": [ 1 ],
            "orderable": false
        }, {
            "render": function (data, type, row) {
                usernames = data.split(',');
                var users_pretty = '';
                $.each( usernames, function (index, value) {
                    users_pretty = users_pretty + '<span class="label label-primary">' + value + '</span>';
                })
                return users_pretty;
            },
            "targets": [ 5, 6, 7 ]
        }],
        "searching": false,
        "order": [3, 'desc'],
        "select": {
            style: 'os'
        }
    });

    /*kalturaDataTable.on('select', function(event) {
        $( "#user_panel" ).slideToggle();
    });

    kalturaDataTable.on('deselect', function(event) {
        $( "#user_panel" ).slideToggle();
    });*/

    // show clear icon if text is present
    media_query.keyup( function() {
        $(".searchclear").toggle(Boolean( $(this).val() ));
    });

    // hide clear icon if empty
    $(".searchclear").toggle( Boolean( media_query.val() ));

    // reset the input field
    $(".searchclear").click( function() {
        media_query.val('').focus();
        $(this).hide();
        input_query = "";
        kalturaDataTable.ajax.reload();
    });

    $( "#search" ).submit(function( event ) {
        input_query = media_query.val();
        // reload the table with new filtered data
        kalturaDataTable.ajax.reload();
        event.preventDefault(); 
    });

    // reset user selection fields
    $("#resetUserSelection").click( function() {
        clearUserSelection();
    });

    $( "#add_users" ).submit(function( event ) {
        var roles = [];
        $( "select#roles option:selected" ).each(function() {
            roles.push($( this ).val());
        });
        var entry_ids = $.map(kalturaDataTable.rows( { selected: true } ).data(), function (item) {
            return item[0]
        });
        //updating_entries.toggleClass('invisible');
        $.blockUI({ message: '<img src="img/spinner-dark.svg"> updating entries...' }); 
        $.post("update_roles.php", {
            "roles": roles,
            "users": user_query.tagsinput('items'),
            "entries": entry_ids,
            }, function ( response ) {
                //updating_entries.toggleClass('invisible');
                kalturaDataTable.ajax.reload();
                clearUserSelection();
                $.unblockUI();
        });
        event.preventDefault(); 
    });

    
});


function clearUserSelection() {
    user_query.tagsinput('removeAll');
    $( "select#roles" ).selectpicker('deselectAll');
}


 //Delete entries -- Clinton
function delete_entries(){
    
    var entry_ids = $.map(kalturaDataTable.rows( { selected: true } ).data(), function (item) {
        return item[0]
    });
    
    console.log(entry_ids);
    
    //updating_entries.toggleClass('invisible');
    $.blockUI({ message: '<img src="img/spinner-dark.svg"> updating entries...' });
    $.post("delete_entries.php", {
        "entries": entry_ids,
    }, function ( response ) {

        console.log(response);
        //updating_entries.toggleClass('invisible');
        kalturaDataTable.ajax.reload();
        clearUserSelection();
        $.unblockUI();
    });
    
    return false;
};
