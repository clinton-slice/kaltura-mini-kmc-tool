Kaltura PHP 5 API Client Library.
Compatible with Kaltura server version 10.20.0 and above.
